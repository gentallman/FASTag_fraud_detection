First Run "python model.py"

then "python app.py"

ctrl+click on the url