import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.model_selection import train_test_split
import pickle

# Load the csv file
df = pd.read_csv('after_feature_engineering.csv')

columns_to_keep = ['Amount_paid', 'Transaction_Amount', 'Vehicle_Speed','Fraud']

df = df.drop(columns=[col for col in df.columns if col not in columns_to_keep])

# Select independent and dependent variable
x = df.drop(columns = ["Fraud"])
y = df["Fraud"]

# Split the dataset into train and test
x_train,x_test,y_train,y_test = train_test_split(x,y, test_size=0.2, random_state=42)


# Instantiate the model
gb_classifier = GradientBoostingClassifier(random_state=42)

# Fit the model
gb_classifier.fit(x_train, y_train)

# Make pickle file of our model
pickle.dump(gb_classifier, open("gb_classifier.pkl", "wb"))
