import numpy as np
from flask import Flask, request, render_template
import pickle
from datetime import datetime

# Create Flask app
app = Flask(__name__)

# Load the trained Random Forest model
model = pickle.load(open("rf_classifier.pkl", "rb"))

# Define the home route
@app.route("/")
def home():
    return render_template("index.html")

# Function to process incoming transaction data
# Function to process incoming transaction data
def process_transaction(amount_paid, transaction_amount, vehicle_speed):
    # Check if full amount is not paid
    if amount_paid < transaction_amount:
        # Return prediction indicating fraud
        return 1
    else:
        # Make prediction based on other features
        features = np.array([[amount_paid, transaction_amount, vehicle_speed]])
        prediction = model.predict(features)
        return prediction


# Function to trigger alert if a fraudulent transaction is detected
def trigger_alert(amount_paid, transaction_amount, vehicle_speed):
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    alert_message = f"ALERT: Potential fraudulent transaction detected at {current_time}\n \n"
    transaction_details = f"\nTransaction details: Amount Paid - {amount_paid}, Transaction Amount - {transaction_amount}, Vehicle Speed - {vehicle_speed}\n"
    alert_message += transaction_details
    return alert_message

# Define the prediction route
@app.route("/predict", methods=["POST"])
def predict():
    # Extract values from the form
    amount_paid = float(request.form["amount_paid"])
    transaction_amount = float(request.form["transaction_amount"])
    vehicle_speed = float(request.form["vehicle_speed"])


    # Process the transaction
    prediction = process_transaction(amount_paid, transaction_amount, vehicle_speed)

    # If fraudulent, trigger an alert
    if prediction == 1:
        alert_message = trigger_alert(amount_paid, transaction_amount, vehicle_speed)
        return render_template("index.html", prediction_text="Fraudulent", alert_message=alert_message)
    else:
        return render_template("index.html", prediction_text="Legitimate")

if __name__ == "__main__":
    app.run(debug=True)
